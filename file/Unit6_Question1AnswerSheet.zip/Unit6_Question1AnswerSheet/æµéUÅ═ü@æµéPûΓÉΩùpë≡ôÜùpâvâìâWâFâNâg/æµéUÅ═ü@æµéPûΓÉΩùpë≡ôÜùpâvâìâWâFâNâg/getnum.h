#include"common.h"

int getnum(const int max, const int min);